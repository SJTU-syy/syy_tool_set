﻿# QFn
整天跟一键自动批处理打交道，所以想到了自动生成界面。
虽然限制蛮多，但胜在效率高。

#### 开发文档
[https://lush_ma.gitee.io/qfn/](https://lush_ma.gitee.io/qfn/)

#### 使用视频
[https://www.bilibili.com/video/av78481300/](https://www.bilibili.com/video/av78481300/)

#### BUG反馈
[https://afdian.net/group/e268edc45df411eaa59b52540025c377](https://afdian.net/group/e268edc45df411eaa59b52540025c377)
